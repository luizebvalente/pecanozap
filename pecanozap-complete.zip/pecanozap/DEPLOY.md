# Peça no Zap - Documentação de Deploy

## Estrutura do Projeto

```
pecanozap/
├── backend/                 # API Flask
│   ├── src/
│   │   ├── models/         # Modelos de dados
│   │   ├── routes/         # Rotas da API
│   │   └── main.py         # Arquivo principal
│   ├── venv/               # Ambiente virtual Python
│   └── requirements.txt    # Dependências Python
├── frontend/               # Aplicação React
│   ├── src/
│   │   ├── components/     # Componentes React
│   │   ├── pages/          # Páginas da aplicação
│   │   ├── lib/            # Utilitários e API
│   │   └── App.jsx         # Componente principal
│   ├── dist/               # Build de produção
│   └── package.json        # Dependências Node.js
└── README.md
```

## Tecnologias Utilizadas

### Backend
- **Flask** - Framework web Python
- **SQLAlchemy** - ORM para banco de dados
- **Flask-JWT-Extended** - Autenticação JWT
- **Flask-CORS** - Cross-origin requests
- **SQLite** - Banco de dados (desenvolvimento)

### Frontend
- **React** - Framework JavaScript
- **Vite** - Build tool
- **Tailwind CSS** - Framework CSS
- **shadcn/ui** - Componentes de UI
- **Lucide Icons** - Ícones
- **Axios** - Cliente HTTP

## Funcionalidades Implementadas

### Para Usuários Finais
✅ Navegação por catálogo de estabelecimentos
✅ Filtros por cidade e categoria
✅ Sistema de busca por texto
✅ Visualização de avaliações (estrelas)
✅ Contato direto via WhatsApp
✅ Interface responsiva (mobile/desktop)
✅ Sistema de avaliações e comentários

### Para Estabelecimentos
✅ Sistema de login/registro
✅ Painel administrativo completo
✅ Cadastro e edição de informações
✅ Gerenciamento de dados de contato
✅ Visualização de avaliações recebidas
✅ Preview de como aparece no site

## APIs Disponíveis

### Autenticação
- `POST /api/register` - Cadastro de estabelecimento
- `POST /api/login` - Login
- `GET /api/profile` - Obter perfil
- `PUT /api/profile` - Atualizar perfil

### Estabelecimentos
- `GET /api/businesses` - Listar estabelecimentos (com filtros)
- `GET /api/businesses/{id}` - Detalhes de um estabelecimento

### Categorias e Cidades
- `GET /api/categories` - Listar categorias
- `GET /api/cities` - Listar cidades

### Avaliações
- `POST /api/reviews` - Criar avaliação
- `GET /api/reviews/{business_id}` - Avaliações de um estabelecimento

## Configuração para Produção

### Backend (Flask)
1. Configurar variáveis de ambiente:
   ```bash
   export FLASK_ENV=production
   export DATABASE_URL=postgresql://...
   export JWT_SECRET_KEY=sua_chave_secreta
   ```

2. Instalar dependências:
   ```bash
   pip install -r requirements.txt
   ```

3. Executar:
   ```bash
   python src/main.py
   ```

### Frontend (React)
1. Build de produção:
   ```bash
   npm run build
   ```

2. Servir arquivos estáticos ou usar servidor web

## Deploy Sugerido

### Opção 1: Vercel + Railway
- **Frontend**: Deploy no Vercel
- **Backend**: Deploy no Railway
- **Banco**: PostgreSQL no Railway

### Opção 2: Heroku
- **Full-stack**: Deploy completo no Heroku
- **Banco**: PostgreSQL add-on

### Opção 3: VPS
- **Servidor**: Ubuntu/CentOS
- **Web Server**: Nginx + Gunicorn
- **Banco**: PostgreSQL

## Configurações de CORS

O backend está configurado para aceitar requisições de:
- `http://localhost:5173` (desenvolvimento)
- `http://localhost:3000` (desenvolvimento)

Para produção, atualizar as origens permitidas em `src/main.py`.

## Banco de Dados

### Desenvolvimento
- SQLite (`pecanozap.db`)
- Criação automática das tabelas
- Dados iniciais populados automaticamente

### Produção
- PostgreSQL recomendado
- Configurar `DATABASE_URL` nas variáveis de ambiente

## Dados Iniciais

O sistema popula automaticamente:
- 8 categorias de estabelecimentos
- 10 cidades principais do Brasil

## Integração WhatsApp

- Links diretos para WhatsApp Web/App
- Mensagem pré-formatada com nome do estabelecimento
- Suporte a números brasileiros (+55)
- Formatação automática de números

## Segurança

- Autenticação JWT
- Senhas com hash (Werkzeug)
- Validação de dados de entrada
- CORS configurado
- Sanitização de inputs

## Performance

- Paginação nas listagens
- Lazy loading de componentes
- Otimização de imagens
- Cache de requisições
- Minificação de assets

## Monitoramento

Recomendado implementar:
- Logs de erro
- Métricas de uso
- Monitoramento de uptime
- Backup automático do banco

