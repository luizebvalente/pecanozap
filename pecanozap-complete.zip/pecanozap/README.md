# Peça no Zap 🚀

Um catálogo digital de estabelecimentos com integração WhatsApp para conectar negócios e clientes.

## 📋 Sobre o Projeto

O **Peça no Zap** é uma plataforma web que funciona como um catálogo de estabelecimentos comerciais organizados por cidade e categoria. Os usuários podem descobrir negócios locais, ver avaliações e entrar em contato diretamente via WhatsApp.

### ✨ Funcionalidades Principais

**Para Clientes:**
- 🔍 Busca e filtros por cidade/categoria
- ⭐ Sistema de avaliações e comentários
- 📱 Contato direto via WhatsApp
- 🎨 Interface moderna e responsiva
- 📍 Localização por cidade

**Para Estabelecimentos:**
- 🔐 Sistema de login e cadastro
- 🏪 Painel administrativo completo
- ✏️ Edição de informações do negócio
- 📊 Visualização de avaliações
- 👀 Preview de como aparece no site

## 🛠️ Tecnologias

### Backend
- **Flask** - Framework web Python
- **SQLAlchemy** - ORM para banco de dados
- **Flask-JWT-Extended** - Autenticação
- **SQLite/PostgreSQL** - Banco de dados

### Frontend
- **React** - Framework JavaScript
- **Vite** - Build tool moderno
- **Tailwind CSS** - Estilização
- **shadcn/ui** - Componentes de UI
- **Axios** - Cliente HTTP

## 🚀 Como Executar

### Pré-requisitos
- Python 3.11+
- Node.js 18+
- pnpm ou npm

### Backend (Flask)
```bash
cd backend
source venv/bin/activate  # Linux/Mac
# ou venv\Scripts\activate  # Windows
pip install -r requirements.txt
python src/main.py
```

### Frontend (React)
```bash
cd frontend
pnpm install
pnpm run dev
```

### Acessar a aplicação
- **Frontend**: http://localhost:5173
- **Backend API**: http://localhost:5001

## 📱 Funcionalidades

### 🏠 Página Inicial
- Hero section atrativo
- Grid de categorias interativo
- Estabelecimentos em destaque
- Call-to-action para cadastro

### 🏪 Catálogo de Estabelecimentos
- Listagem com paginação
- Filtros por cidade e categoria
- Sistema de busca por texto
- Cards informativos com avaliações

### 🔐 Sistema de Autenticação
- Login e cadastro de estabelecimentos
- Validação de dados
- Redirecionamento automático

### 📊 Painel Administrativo
- Dashboard com estatísticas
- Edição de informações
- Visualização de avaliações
- Preview do estabelecimento

### ⭐ Sistema de Avaliações
- Avaliação por estrelas (1-5)
- Comentários opcionais
- Moderação de conteúdo
- Cálculo de média automático

### 📱 Integração WhatsApp
- Botões de contato direto
- Mensagens pré-formatadas
- Suporte a números brasileiros
- Abertura em nova aba

## 🎨 Design

- **Cores**: Paleta baseada no WhatsApp (verde #25D366)
- **Tipografia**: Fonte system (sans-serif)
- **Layout**: Responsivo mobile-first
- **Componentes**: Modernos com hover effects
- **Ícones**: Lucide Icons

## 📊 Estrutura do Banco

### Tabelas Principais
- **users** - Estabelecimentos cadastrados
- **categories** - Categorias de negócio
- **cities** - Cidades disponíveis
- **reviews** - Avaliações dos usuários

### Relacionamentos
- User → City (N:1)
- User → Category (N:1)
- Review → User (N:1)

## 🔧 APIs Disponíveis

### Autenticação
- `POST /api/register` - Cadastro
- `POST /api/login` - Login
- `GET /api/profile` - Perfil do usuário
- `PUT /api/profile` - Atualizar perfil

### Dados
- `GET /api/businesses` - Listar estabelecimentos
- `GET /api/businesses/{id}` - Detalhes
- `GET /api/categories` - Categorias
- `GET /api/cities` - Cidades
- `POST /api/reviews` - Criar avaliação

## 🌟 Destaques Técnicos

- **Responsivo**: Funciona perfeitamente em mobile e desktop
- **Performance**: Lazy loading e otimizações
- **Segurança**: JWT, hash de senhas, validações
- **UX**: Transições suaves, feedback visual
- **SEO**: Meta tags otimizadas

## 📈 Próximos Passos

- [ ] Upload de imagens dos estabelecimentos
- [ ] Sistema de favoritos
- [ ] Notificações push
- [ ] Integração com mapas
- [ ] App mobile nativo
- [ ] Sistema de cupons/promoções

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature
3. Commit suas mudanças
4. Push para a branch
5. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

## 📞 Contato

Desenvolvido com ❤️ para conectar pessoas e negócios através do WhatsApp.

---

**Peça no Zap** - Encontre, conecte-se e cresça! 🚀

